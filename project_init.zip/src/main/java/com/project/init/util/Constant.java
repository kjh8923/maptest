package com.project.init.util;

import com.project.init.dao.PlanDao;

public class Constant {
	public static PlanDao pdao;
}
